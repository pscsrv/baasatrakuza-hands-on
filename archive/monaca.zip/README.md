# BaaS@rakuza ハンズ・オン for Monaca

`BaaS@rakuza` x `Monaca` を体験するためのハンズ・オン用のソースです。




